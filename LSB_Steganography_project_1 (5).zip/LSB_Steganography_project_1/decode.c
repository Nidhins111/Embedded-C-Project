#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "decode.h"
#include "types.h"
#include "common.h"

Status  open_decode_files(DecodeInfo *decInfo)
{
    // Src Image file
    
    decInfo->fptr_decode_stego_image = fopen(decInfo->stego_image_fname, "r");
    // Do Error handling
    if (decInfo->fptr_decode_stego_image == NULL)
    { 
    	perror("fopen");
    	fprintf(stderr, "ERROR: Unable to open file %s\n",decInfo->stego_image_fname );

    	return e_failure;
    }
decInfo->fptr_decode = fopen(decInfo->decode_fname, "w");
    
if (decInfo-> fptr_decode== NULL)
    {
        perror("fopen");
        fprintf(stderr, "ERROR: Unable to open file %s\n", decInfo->decode_fname);
        return e_failure;
    }

 
    // No failure return e_success
    return e_success;
}

Status decode_byte_frm_lsb( char *data, char *image_bufferr )
{ 
    unsigned char ch = 0x00;
    for( int i =0; i < 8; i++ )
    {
        
       ch =((image_bufferr[i] & 0x01 ) << (7-i))| ch;
    }
   
    *data = ch;
    return e_success;
}

Status decode_image_to_magic_data( int size, FILE *fptr_stego, DecodeInfo *decInfo)
{
    char str[8];

    for (int i =0; i<size; i++)
    {
        
        fread(str, 8, sizeof(char), fptr_stego);
        decode_byte_frm_lsb( &decInfo -> image_data[i],str );
        
    }
    return e_success;
}

Status decode_magic_string(DecodeInfo *decInfo)
 {
    fseek(decInfo->fptr_decode_stego_image, 54, SEEK_SET);
    decode_image_to_magic_data(strlen(MAGIC_STRING), decInfo->fptr_decode_stego_image, decInfo);
    
    // Null-terminate the decoded message
    decInfo->image_data[strlen(MAGIC_STRING)] = '\0';

    if (strcmp(decInfo->image_data, MAGIC_STRING) == 0) {
        return e_success;
    }
    else 
    {
        return e_failure;
    }
}

Status decode_secret_file_extn( DecodeInfo *decInfo)
{
    char file_ext[8] = ".txt";
    int i = strlen(file_ext);
    decInfo-> dec_extn_secret_file = malloc(i + 1);
    decode_extn_to_data( strlen(file_ext), decInfo -> fptr_decode_stego_image, decInfo);
    decInfo->dec_extn_secret_file[strlen(file_ext)] = '\0';
    

    if (strcmp(decInfo->dec_extn_secret_file, file_ext) == 0)
     {
        return e_success; 
    }
    else
     {
        return e_failure;
    }

   
}

Status decode_extn_to_data(  int size, FILE *fptr_stego,  DecodeInfo *decInfo)
{
    char str[8];

    for (int i =0; i<size; i++)
    {
        //read 8 bytes of info from .bmp
        fread(str, 8, sizeof(char), fptr_stego);
        decode_byte_frm_lsb( &decInfo -> dec_extn_secret_file[i],str );
        
    }
    return e_success;

}

Status decode_size_to_lsb(char *buffer, long int *size)
{
    unsigned int num = 0x00;
    for( int i =0; i < 32; i++ )
    {
       num =((buffer[i] & 0x01 ) << (31-i))| num;
    }
    *size=num;
    return e_success;
  

}

Status decode_file_extn_size(long file_extn_size, DecodeInfo *decInfo)
{
    char str[32];
    fread(str, 32, sizeof(char), decInfo -> fptr_decode_stego_image );
    decode_size_to_lsb(str, &file_extn_size);
    decInfo -> size_secret_file_extn = file_extn_size;
    return e_success;
}

Status decode_secret_file_size(long file,DecodeInfo *decInfo)
{
    char str[32];
    fread(str, 32, sizeof(char), decInfo-> fptr_decode_stego_image );
    decode_size_to_lsb(str, &file);
    decInfo->size_secret_file = file;
    
    
    return e_success;
}

Status decode_secret_file_data(DecodeInfo *decInfo)
{ 
    
    char ch;
  decInfo->stego_data = (char *)malloc(sizeof(char) * 8);
    
    for( int i =0; i < decInfo -> size_secret_file; i++)
        {
           
            fread(decInfo -> stego_data, 8, sizeof(char), decInfo -> fptr_decode_stego_image);
            decode_byte_frm_lsb(&ch, decInfo -> stego_data);
           
            fputc(ch, decInfo->fptr_decode);
             
        }
        
        return e_success;
}


Status read_and_validate_decode_args(char *argv[], DecodeInfo *decInfo)
{
    if( argv[2] != NULL && strcmp(strstr(argv[2], "."),".bmp") == 0)
    {
        decInfo -> stego_image_fname = argv[2];
       
    }
    else
    {
        return e_failure;
    }
   
    if( argv[3] != NULL )
    {
       decInfo -> decode_fname = argv[3];
    }
    else
    {
       decInfo ->decode_fname   = "decode.txt";
    }

return e_success;

}

Status do_decoding(DecodeInfo *decInfo)
{
    if (open_decode_files(decInfo ) == e_success)
    {
        printf("Opened all files successfully.\n");
         printf("Started decoding\n");
         if (decode_magic_string(decInfo) == e_success)
         {
            printf("Decoded magic string successfully.\n");
            if(decode_file_extn_size(decInfo -> size_secret_file_extn, decInfo) == e_success)
            {
                printf("Successfully decoded the secret file size. \n");
                if((decode_secret_file_extn(decInfo) == e_success))
                {
                    printf("Successfully decoded the secret file extension. \n");
                    if (decode_secret_file_size(decInfo -> size_secret_file, decInfo) == e_success)
                    {
                        printf("Successfully decoded the secret file size. \n");
                        if(decode_secret_file_data(decInfo) == e_success)
                        {
                            printf("Successfully decoded the secret file data.\n");
                        }
                        else
                        {
                             printf("Failed to decode the secret file data.\n");
                             return e_failure;
                        }

                    }
                    else
                    {
                        printf("Failed to decode the secret file data \n");
                        return e_failure;
                    }
                }
                else
                {
                   printf("Failed to decode the secret file extension \n"); 
                   return e_failure;
                }


            }
            else
            {
                printf("Failed to decode the secret file size \n");
                return e_failure;
            }
         }
         else
         {
            printf("Failed to decode the magic string\n");
            return e_failure;
         }
    }
    else
    {
        printf("Failed to open the file\n");
        return e_failure;
    }
    return e_success;
   
}