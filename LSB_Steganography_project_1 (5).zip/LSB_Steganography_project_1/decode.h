#ifndef DECODE_H
#define DECODE_H

#include "types.h"


#define MAX_SECRET_BUF_SIZE 1
#define MAX_IMAGE_BUF_SIZE (MAX_SECRET_BUF_SIZE * 8)
#define MAX_FILE_SUFFIX 4

typedef struct _DecodeInfo
{
   /*stego Image Info*/ 
   char *stego_image_fname;
   FILE *fptr_decode_stego_image;
   char image_data[MAX_SECRET_BUF_SIZE];

   /*Decode File Info*/
   char *decode_fname;
   FILE *fptr_decode;
   char *stego_data;
   char *dec_extn_secret_file;
   int size_secret_file_extn;
   int size_secret_file;

} DecodeInfo;
//Function declaration to read and validate command line arguments
Status read_and_validate_decode_args(char *argv[], DecodeInfo *decInfo);

/*Function declaration to do decoding*/
Status do_decoding(DecodeInfo *decInfo);

/*Function declaration to open files needed for decding*/
Status open_decode_files(DecodeInfo *decInfo);

/*Function declaration to decode magic string*/
Status decode_magic_string( DecodeInfo *decInfo);

/*Function  declaration to decode_image_to_magic_data*/
Status decode_image_to_magic_data(  int size, FILE *fptr_decode_stego_image,  DecodeInfo *decInfo);

/*Function  declaration to decode byte from LSB*/
Status decode_byte_frm_lsb( char *data, char *image_bufferr );

/*Function  declaration to decode secret file extension*/
Status decode_secret_file_extn(DecodeInfo *decInfo);

/*Function  declaration to decode secret file extension*/
Status decode_extn_to_data(  int size, FILE *fptr_decode_stego_image,  DecodeInfo *decInfo);

/*Function  declaration to decode secret file extension size */
Status decode_file_extn_size(long file_extn_size, DecodeInfo *decInfo);

/*Function to decode size from LSB*/
Status decode_size_to_lsb(char *buffer, long int *size);

/*Function  declaration to decode secret file data*/
Status decode_secret_file_data(DecodeInfo *decInfo);

/*Function  declaration to  decode secret file size*/
Status decode_secret_file_size(long file_size, DecodeInfo *decInfo);
#endif